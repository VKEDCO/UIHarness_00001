/** Automatically generated file. DO NOT MODIFY */
package org.vkedco.android.uiharness;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}